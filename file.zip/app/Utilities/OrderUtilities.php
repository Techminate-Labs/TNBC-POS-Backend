<?php
namespace App\Utilities;

class OrderUtilities{
    public function createCart(){
        //
    }
}