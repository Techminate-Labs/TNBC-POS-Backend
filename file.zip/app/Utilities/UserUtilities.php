<?php
namespace App\Utilities;

class UserUtilities{
    //
}