TNB-POS is a Point of Sales specially designed to accept "TNBC" as the payment. "TNBC" the Crypto Currency of "The New Boston".

Framework : Laravel

Packages : Sanctum

Setup Instructions : 

step 1 : Install xampp

step 2 : then go to xampp/htdocs

step 3 : clone this github repo

step 4 : rename env.xample to .env and add database name

step 5 : create a database in phpmyadmin or any sql database

step 6 : open terminal and run "composer install"

step 7 : then run "php artisan storage:link"

step 8 : then run "php artisan serve"


